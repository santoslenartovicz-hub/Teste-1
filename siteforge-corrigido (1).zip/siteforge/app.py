"""
SiteForge IA - Encontre lojas sem site e gere sites prontos para publicar.
100% gratuito: OpenStreetMap (Overpass + Nominatim) para dados,
gerador de sites por template + IA opcional (chave gratuita OpenRouter/Groq).
"""
import io
import os
import re
import json
import time
import html
import zipfile
import unicodedata
from urllib.parse import quote
from typing import Optional, List, Dict, Any

import httpx
from fastapi import FastAPI, Body
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "out")
os.makedirs(OUT, exist_ok=True)

app = FastAPI(title="SiteForge IA")

UA = {"User-Agent": "SiteForgeIA/1.0 (gerador de sites para pequenos negocios)"}

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
]

# Categorias -> filtros OSM
CATEGORIES: Dict[str, List[str]] = {
    "todos": ['["shop"]', '["amenity"~"restaurant|cafe|bar|fast_food|pharmacy|bakery|clinic|dentist|veterinary|fuel|bank"]', '["craft"]', '["office"]', '["leisure"~"fitness_centre|sports_centre"]'],
    "lojas": ['["shop"]'],
    "restaurantes": ['["amenity"~"restaurant|cafe|bar|fast_food|ice_cream|pub"]'],
    "padarias": ['["shop"="bakery"]', '["shop"="pastry"]'],
    "beleza": ['["shop"~"hairdresser|beauty|massage|tattoo"]'],
    "saude": ['["amenity"~"pharmacy|clinic|dentist|doctors|veterinary"]', '["healthcare"]'],
    "oficinas": ['["shop"~"car_repair|tyres|motorcycle_repair|bicycle"]', '["craft"]'],
    "academias": ['["leisure"~"fitness_centre|sports_centre"]'],
    "mercados": ['["shop"~"supermarket|convenience|greengrocer|butcher"]'],
    "servicos": ['["office"]', '["craft"]'],
    "hoteis": ['["tourism"~"hotel|guest_house|hostel|motel"]'],
}

CAT_LABEL = {
    "restaurant": "Restaurante", "cafe": "Cafeteria", "bar": "Bar", "fast_food": "Lanchonete",
    "pharmacy": "Farmácia", "bakery": "Padaria", "hairdresser": "Salão de Beleza",
    "beauty": "Estética", "supermarket": "Supermercado", "convenience": "Mercearia",
    "clothes": "Loja de Roupas", "car_repair": "Oficina Mecânica", "butcher": "Açougue",
    "florist": "Floricultura", "hardware": "Loja de Materiais", "furniture": "Loja de Móveis",
    "shoes": "Loja de Calçados", "jewelry": "Joalheria", "optician": "Ótica",
    "pet": "Pet Shop", "veterinary": "Clínica Veterinária", "dentist": "Consultório Odontológico",
    "doctors": "Clínica Médica", "fitness_centre": "Academia", "hotel": "Hotel",
    "bicycle": "Bicicletaria", "greengrocer": "Hortifruti", "pastry": "Confeitaria",
    "tattoo": "Estúdio de Tatuagem", "massage": "Casa de Massagem", "ice_cream": "Sorveteria",
    "mobile_phone": "Loja de Celulares", "computer": "Assistência de Informática",
    "books": "Livraria", "toys": "Loja de Brinquedos", "sports": "Loja de Esportes",
    "car": "Concessionária", "tyres": "Borracharia", "electronics": "Loja de Eletrônicos",
    "bank": "Banco", "fuel": "Posto de Combustível", "guest_house": "Pousada",
    "hostel": "Hostel", "motel": "Motel", "pub": "Pub", "alcohol": "Adega",
    "variety_store": "Loja de Variedades", "department_store": "Loja de Departamentos",
    "car_parts": "Autopeças", "garden_centre": "Agropecuária", "agrarian": "Agropecuária",
    "stationery": "Papelaria", "copyshop": "Gráfica", "laundry": "Lavanderia",
    "dry_cleaning": "Lavanderia", "travel_agency": "Agência de Viagens",
    "estate_agent": "Imobiliária", "funeral_directors": "Funerária",
    "kiosk": "Quiosque", "tailor": "Costureira", "carpenter": "Marcenaria",
    "electrician": "Eletricista", "plumber": "Encanador", "painter": "Pintor",
    "photographer": "Estúdio Fotográfico", "shoemaker": "Sapataria",
}

WEBSITE_KEYS = ("website", "contact:website", "url", "website:official", "contact:facebook", "facebook")


def slugify(txt: str) -> str:
    txt = unicodedata.normalize("NFKD", txt or "").encode("ascii", "ignore").decode()
    txt = re.sub(r"[^a-zA-Z0-9]+", "-", txt).strip("-").lower()
    return txt or "negocio"


CAT_LABEL_EN = {
    "restaurant": "Restaurant", "cafe": "Coffee Shop", "bar": "Bar", "fast_food": "Fast Food",
    "pharmacy": "Pharmacy", "bakery": "Bakery", "hairdresser": "Hair Salon", "beauty": "Beauty Salon",
    "supermarket": "Supermarket", "convenience": "Convenience Store", "clothes": "Clothing Store",
    "car_repair": "Auto Repair Shop", "butcher": "Butcher Shop", "florist": "Flower Shop",
    "hardware": "Hardware Store", "furniture": "Furniture Store", "shoes": "Shoe Store",
    "jewelry": "Jewelry Store", "optician": "Optician", "pet": "Pet Shop",
    "veterinary": "Veterinary Clinic", "dentist": "Dental Office", "doctors": "Medical Clinic",
    "fitness_centre": "Gym", "hotel": "Hotel", "bicycle": "Bike Shop", "greengrocer": "Produce Market",
    "pastry": "Pastry Shop", "tattoo": "Tattoo Studio", "massage": "Massage Studio",
    "ice_cream": "Ice Cream Shop", "mobile_phone": "Phone Store", "computer": "Computer Repair",
    "books": "Bookstore", "toys": "Toy Store", "sports": "Sporting Goods", "car": "Car Dealership",
    "tyres": "Tire Shop", "electronics": "Electronics Store", "bank": "Bank", "fuel": "Gas Station",
    "laundry": "Laundromat", "dry_cleaning": "Dry Cleaner", "travel_agency": "Travel Agency",
    "estate_agent": "Real Estate Agency", "stationery": "Stationery Store", "copyshop": "Print Shop",
    "guest_house": "Guest House", "hostel": "Hostel", "pub": "Pub", "alcohol": "Liquor Store",
    "car_parts": "Auto Parts Store", "photographer": "Photo Studio", "tailor": "Tailor",
}


def label_for(tags: Dict[str, str], lang: str = "pt") -> str:
    table = CAT_LABEL if lang == "pt" else CAT_LABEL_EN
    for k in ("shop", "amenity", "craft", "office", "leisure", "tourism", "healthcare"):
        v = tags.get(k)
        if v:
            return table.get(v, v.replace("_", " ").title())
    return "Negócio Local" if lang == "pt" else "Local Business"


# ---------------------------------------------------------------- geocode
async def geocode(place: str, iso: str = "") -> Optional[Dict[str, Any]]:
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": place, "format": "json", "limit": 1, "polygon_geojson": 0, "accept-language": "pt-BR"}
    if iso:
        params["countrycodes"] = iso
    async with httpx.AsyncClient(timeout=30, headers=UA) as c:
        r = await c.get(url, params=params)
        data = r.json()
    if not data:
        return None
    d = data[0]
    bb = [float(x) for x in d["boundingbox"]]  # south, north, west, east
    return {"name": d.get("display_name"), "lat": float(d["lat"]), "lon": float(d["lon"]),
            "bbox": (bb[0], bb[2], bb[1], bb[3])}  # s,w,n,e


async def overpass(query: str) -> Dict[str, Any]:
    last = None
    async with httpx.AsyncClient(timeout=120, headers=UA) as c:
        for ep in OVERPASS_ENDPOINTS:
            try:
                r = await c.post(ep, data={"data": query})
                if r.status_code == 200:
                    return r.json()
                last = f"HTTP {r.status_code}"
            except Exception as e:  # noqa
                last = str(e)
    raise RuntimeError(f"Overpass indisponível: {last}")


# ------------------------------------------------- países / estados / cidades
CACHE_DIR = os.path.join(BASE, ".loccache")
os.makedirs(CACHE_DIR, exist_ok=True)
CN = "https://countriesnow.space/api/v0.1"

TOP_COUNTRIES = [
    ("Brazil", "Brasil", "br", "pt"), ("United States", "Estados Unidos", "us", "en"),
    ("Portugal", "Portugal", "pt", "pt"), ("Canada", "Canadá", "ca", "en"),
    ("United Kingdom", "Reino Unido", "gb", "en"), ("Ireland", "Irlanda", "ie", "en"),
    ("Australia", "Austrália", "au", "en"), ("Spain", "Espanha", "es", "es"),
    ("Mexico", "México", "mx", "es"), ("Argentina", "Argentina", "ar", "es"),
    ("Chile", "Chile", "cl", "es"), ("Colombia", "Colômbia", "co", "es"),
    ("Paraguay", "Paraguai", "py", "es"), ("Uruguay", "Uruguai", "uy", "es"),
    ("Italy", "Itália", "it", "en"), ("France", "França", "fr", "en"),
    ("Germany", "Alemanha", "de", "en"), ("Japan", "Japão", "jp", "en"),
]
LANG_BY_COUNTRY = {c[0]: c[3] for c in TOP_COUNTRIES}
ISO_BY_COUNTRY = {c[0]: c[2] for c in TOP_COUNTRIES}


def cache_get(name: str):
    p = os.path.join(CACHE_DIR, slugify(name) + ".json")
    if os.path.exists(p) and time.time() - os.path.getmtime(p) < 60 * 60 * 24 * 30:
        try:
            return json.load(open(p, encoding="utf-8"))
        except Exception:
            return None
    return None


def cache_put(name: str, data):
    try:
        json.dump(data, open(os.path.join(CACHE_DIR, slugify(name) + ".json"), "w", encoding="utf-8"))
    except Exception:
        pass


async def get_json(url: str, timeout=30):
    async with httpx.AsyncClient(timeout=timeout, headers=UA, follow_redirects=True) as c:
        r = await c.get(url)
        return r.json()


@app.get("/api/countries")
async def countries():
    cached = cache_get("countries")
    if cached:
        return cached
    extra = []
    try:
        d = await get_json(f"{CN}/countries/iso")
        tops = {c[0] for c in TOP_COUNTRIES}
        for x in d.get("data", []):
            if x["name"] not in tops:
                extra.append({"value": x["name"], "label": x["name"],
                              "iso": (x.get("Iso2") or "").lower(), "lang": "en"})
    except Exception:
        pass
    out = {"top": [{"value": v, "label": l, "iso": i, "lang": g} for v, l, i, g in TOP_COUNTRIES],
           "others": sorted(extra, key=lambda x: x["label"])}
    cache_put("countries", out)
    return out


@app.get("/api/states")
async def states(country: str = "Brazil"):
    ck = f"states-{country}"
    cached = cache_get(ck)
    if cached:
        return cached
    out = []
    try:
        if country == "Brazil":
            d = await get_json("https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome")
            out = [{"value": s["nome"], "label": f"{s['nome']} ({s['sigla']})", "id": s["id"]} for s in d]
        else:
            d = await get_json(f"{CN}/countries/states/q?country={quote(country)}")
            out = [{"value": s["name"], "label": s["name"]} for s in d["data"]["states"]]
    except Exception as e:
        return {"error": str(e), "states": []}
    res = {"states": out}
    if out:
        cache_put(ck, res)
    return res


@app.get("/api/cities")
async def cities(country: str = "Brazil", state: str = "", state_id: int = 0):
    ck = f"cities-{country}-{state}"
    cached = cache_get(ck)
    if cached:
        return cached
    out = []
    try:
        if country == "Brazil" and state_id:
            d = await get_json(f"https://servicodados.ibge.gov.br/api/v1/localidades/estados/{state_id}/municipios")
            out = [{"value": m["nome"], "label": m["nome"]} for m in d]
        else:
            d = await get_json(f"{CN}/countries/state/cities/q?country={quote(country)}&state={quote(state)}", 45)
            out = [{"value": c, "label": c} for c in d["data"]]
    except Exception as e:
        return {"error": str(e), "cities": []}
    res = {"cities": out}
    if out:
        cache_put(ck, res)
    return res


@app.post("/api/search")
async def search(payload: Dict[str, Any] = Body(...)):
    place = (payload.get("place") or "").strip()
    country = (payload.get("country") or "").strip()
    state = (payload.get("state") or "").strip()
    city = (payload.get("city") or "").strip()
    if not place and (city or state):
        place = ", ".join(x for x in [city, state, country] if x)
    category = payload.get("category") or "todos"
    only_no_site = payload.get("only_no_site", True)
    limit = int(payload.get("limit") or 60)
    radius = int(payload.get("radius") or 0)  # metros; 0 = bbox da cidade

    if not place:
        return JSONResponse({"error": "Informe a cidade/bairro/região."}, status_code=400)

    lang = LANG_BY_COUNTRY.get(country, "pt" if not country else "en")
    iso = ISO_BY_COUNTRY.get(country, "")
    geo = await geocode(place, iso)
    if not geo:
        return JSONResponse({"error": f"Não encontrei a região '{place}'. Tente 'Cidade, Estado, Brasil'."}, status_code=404)

    filters = CATEGORIES.get(category, CATEGORIES["todos"])
    if radius > 0:
        areas = [f"(around:{radius},{geo['lat']},{geo['lon']})"]
    else:
        s, w, n, e = geo["bbox"]
        # 1) bbox da região; 2) fallback 25km ao redor (cidades pequenas sem POIs mapeados)
        areas = [f"({s},{w},{n},{e})", f"(around:25000,{geo['lat']},{geo['lon']})"]

    data, expanded = {"elements": []}, False
    for idx, area in enumerate(areas):
        parts = []
        for f in filters:
            for t in ("node", "way"):
                parts.append(f"{t}{f}{area};")
        q = f"[out:json][timeout:90];({''.join(parts)});out center tags {max(limit*6, 300)};"
        data = await overpass(q)
        if any((el.get("tags") or {}).get("name") for el in data.get("elements", [])):
            expanded = idx > 0
            break
        expanded = idx > 0

    seen, results = set(), []
    for el in data.get("elements", []):
        tags = el.get("tags", {}) or {}
        name = tags.get("name")
        if not name:
            continue
        has_site = any(tags.get(k) for k in WEBSITE_KEYS)
        if only_no_site and has_site:
            continue
        key = (name.lower(), round(el.get("lat") or el.get("center", {}).get("lat", 0), 4))
        if key in seen:
            continue
        seen.add(key)
        street = tags.get("addr:street", "")
        num = tags.get("addr:housenumber", "")
        addr = " ".join(x for x in [street, num] if x)
        results.append({
            "id": f"{el['type']}/{el['id']}",
            "name": name,
            "category": label_for(tags, lang),
            "raw_category": tags.get("shop") or tags.get("amenity") or tags.get("craft") or "",
            "address": addr,
            "city": tags.get("addr:city") or place.split(",")[0].strip(),
            "state": tags.get("addr:state", ""),
            "postcode": tags.get("addr:postcode", ""),
            "phone": tags.get("phone") or tags.get("contact:phone") or "",
            "whatsapp": tags.get("contact:whatsapp", ""),
            "email": tags.get("email") or tags.get("contact:email") or "",
            "instagram": tags.get("contact:instagram", ""),
            "hours": tags.get("opening_hours", ""),
            "cuisine": tags.get("cuisine", ""),
            "lat": el.get("lat") or el.get("center", {}).get("lat"),
            "lon": el.get("lon") or el.get("center", {}).get("lon"),
            "country": country, "iso": iso, "lang": lang,
            "has_site": has_site,
            "website": next((tags.get(k) for k in WEBSITE_KEYS if tags.get(k)), ""),
        })
        if len(results) >= limit:
            break

    # score: quanto mais dados de contato, mais "quente" o lead
    for r in results:
        s = 0
        s += 35 if r["phone"] or r["whatsapp"] else 0
        s += 20 if r["address"] else 0
        s += 15 if r["hours"] else 0
        s += 15 if r["email"] else 0
        s += 15 if not r["has_site"] else 0
        r["score"] = min(100, s)
    results.sort(key=lambda x: -x["score"])

    note = ""
    if expanded:
        note = "Poucos negócios mapeados nessa região — ampliei a busca para um raio de 25 km."
    if not results:
        note = ("Nenhum negócio encontrado. Essa região ainda tem pouco cadastro no OpenStreetMap. "
                "Tente a cidade vizinha maior, aumente o raio ou escolha 'Todos os negócios'.")
    return {"region": geo["name"], "lang": lang, "center": {"lat": geo["lat"], "lon": geo["lon"]},
            "count": len(results), "results": results, "note": note}


# ---------------------------------------------------------------- IA texto / i18n
I18N = {
    "pt": {
        "hero": "Qualidade, atendimento próximo e a confiança de quem é do bairro.",
        "about": ("A {cat} {name} atende {city} com dedicação, produtos selecionados e um atendimento "
                  "que trata cada cliente pelo nome. Aqui você encontra preço justo, agilidade e a certeza "
                  "de ser bem recebido em todas as visitas."),
        "services": [
            ("Atendimento personalizado", "Equipe pronta para entender o que você precisa e resolver rápido."),
            ("Preço justo", "Condições especiais, formas de pagamento facilitadas e promoções para clientes fiéis."),
            ("Perto de você", "Localização de fácil acesso em {city}, com atendimento ágil no balcão e por telefone."),
        ],
        "cta": "Fale agora e garanta seu atendimento",
        "seo": "{name} em {city}. {cat} com atendimento de confiança, contato e horários.",
        "ui": {"about": "Sobre nós", "services": "Serviços", "contact": "Contato", "talk": "Falar agora",
               "offer": "O que oferecemos", "offer_sub": "Tudo pensado para atender você com rapidez, qualidade e preço justo.",
               "addr": "Endereço", "hours": "Horário", "phone": "Telefone", "cat": "Categoria",
               "map": "Ver no mapa", "route": "Como chegar", "default_hours": "Segunda a Sábado, 08h às 18h",
               "no_addr": "Consulte pelo telefone", "no_phone": "Entre em contato pelas redes",
               "made": "Site criado com SiteForge IA", "mapdata": "Mapa"},
    },
    "en": {
        "hero": "Quality service, fair prices and the trust of your neighborhood.",
        "about": ("{name} proudly serves {city} as a trusted {cat}. We combine carefully selected products, "
                  "friendly service and fair prices, treating every customer by name.\n"
                  "Stop by, call us or send a message - we are ready to help you today."),
        "services": [
            ("Personal service", "A team that listens to what you need and solves it fast."),
            ("Fair pricing", "Honest prices, flexible payment options and deals for regular customers."),
            ("Close to you", "Easy to reach in {city}, with quick service in store and over the phone."),
        ],
        "cta": "Get in touch today",
        "seo": "{name} in {city}. Trusted {cat} - contact details, hours and directions.",
        "ui": {"about": "About us", "services": "Services", "contact": "Contact", "talk": "Contact us",
               "offer": "What we offer", "offer_sub": "Everything designed to serve you quickly, well and at a fair price.",
               "addr": "Address", "hours": "Hours", "phone": "Phone", "cat": "Category",
               "map": "View on map", "route": "Get directions", "default_hours": "Monday to Saturday, 8am - 6pm",
               "no_addr": "Call us for directions", "no_phone": "Reach us on social media",
               "made": "Website built with SiteForge AI", "mapdata": "Map"},
    },
    "es": {
        "hero": "Calidad, atención cercana y la confianza de siempre.",
        "about": ("{name} atiende a {city} como {cat} de confianza, con productos seleccionados, "
                  "atención cercana y precios justos para cada cliente.\n"
                  "Visítanos, llámanos o escríbenos: estamos listos para ayudarte hoy mismo."),
        "services": [
            ("Atención personalizada", "Un equipo que escucha lo que necesitas y lo resuelve rápido."),
            ("Precio justo", "Precios honestos, medios de pago flexibles y promociones para clientes fieles."),
            ("Cerca de ti", "Fácil acceso en {city}, con atención ágil en el local y por teléfono."),
        ],
        "cta": "Contáctanos hoy mismo",
        "seo": "{name} en {city}. {cat} de confianza: contacto, horarios y ubicación.",
        "ui": {"about": "Sobre nosotros", "services": "Servicios", "contact": "Contacto", "talk": "Contactar",
               "offer": "Qué ofrecemos", "offer_sub": "Todo pensado para atenderte rápido, bien y a precio justo.",
               "addr": "Dirección", "hours": "Horario", "phone": "Teléfono", "cat": "Categoría",
               "map": "Ver en el mapa", "route": "Cómo llegar", "default_hours": "Lunes a sábado, 8:00 - 18:00",
               "no_addr": "Consulta por teléfono", "no_phone": "Escríbenos por redes sociales",
               "made": "Sitio creado con SiteForge IA", "mapdata": "Mapa"},
    },
}

AI_PROMPT_LANG = {"pt": "português do Brasil", "en": "English (US)", "es": "español neutro"}


async def ai_copy(biz: Dict[str, Any], api_key: str, model: str, extra: str = "", lang: str = "pt") -> Optional[Dict[str, Any]]:
    if not api_key:
        return None
    target = AI_PROMPT_LANG.get(lang, "português do Brasil")
    prompt = f"""You are a website copywriter for small local businesses.
Business: {biz.get('name')}
Type: {biz.get('category')}
City: {biz.get('city')}
Address: {biz.get('address')}
Country: {biz.get('country') or ''}
User notes: {extra or 'none'}

Write ALL output text in {target}. Do not invent awards, dates or fake numbers.
Reply with ONLY a valid JSON object:
{{"tagline":"short punchy line (max 70 chars)",
"about":"2 short paragraphs about the business, warm tone",
"services":[{{"title":"...","text":"..."}},{{"title":"...","text":"..."}},{{"title":"...","text":"..."}}],
"cta":"short call to action",
"seo":"meta description up to 150 chars"}}"""
    base = "https://openrouter.ai/api/v1/chat/completions"
    if api_key.startswith("gsk_"):
        base = "https://api.groq.com/openai/v1/chat/completions"
        model = model or "llama-3.3-70b-versatile"
    try:
        async with httpx.AsyncClient(timeout=90) as c:
            r = await c.post(base, headers={"Authorization": f"Bearer {api_key}",
                                            "Content-Type": "application/json"},
                             json={"model": model or "meta-llama/llama-3.3-70b-instruct:free",
                                   "messages": [{"role": "user", "content": prompt}],
                                   "temperature": 0.8})
            txt = r.json()["choices"][0]["message"]["content"]
        m = re.search(r"\{.*\}", txt, re.S)
        return json.loads(m.group(0)) if m else None
    except Exception:
        return None


def build_copy(biz: Dict[str, Any], ai: Optional[Dict[str, Any]], lang: str = "pt") -> Dict[str, Any]:
    L = I18N.get(lang, I18N["pt"])
    lk = lang if lang in I18N else "pt"
    city = biz.get("city") or {"pt": "sua região", "en": "your area", "es": "tu zona"}[lk]
    cat = biz.get("category") or {"pt": "Negócio Local", "en": "Local Business", "es": "Negocio Local"}[lk]
    name = biz.get("name") or ""
    base_seo = L["seo"].format(name=name, city=city, cat=cat)
    if ai:
        return {
            "tagline": ai.get("tagline") or L["hero"],
            "about": ai.get("about") or L["about"].format(cat=cat.lower(), name=name, city=city),
            "services": [(x.get("title", ""), x.get("text", "")) for x in (ai.get("services") or [])][:3] or
                        [(t, x.format(city=city)) for t, x in L["services"]],
            "cta": ai.get("cta") or L["cta"],
            "seo": ai.get("seo") or base_seo,
        }
    return {
        "tagline": L["hero"],
        "about": L["about"].format(cat=cat.lower(), name=name, city=city),
        "services": [(t, x.format(city=city)) for t, x in L["services"]],
        "cta": L["cta"],
        "seo": base_seo,
    }


THEMES = {
    "esmeralda": ("#0f766e", "#14b8a6", "#ecfdf5", "#062e2b"),
    "indigo": ("#4338ca", "#6366f1", "#eef2ff", "#1e1b4b"),
    "laranja": ("#c2410c", "#f97316", "#fff7ed", "#431407"),
    "vinho": ("#9f1239", "#e11d48", "#fff1f2", "#4c0519"),
    "grafite": ("#1f2937", "#4b5563", "#f8fafc", "#0b1220"),
}


DIAL = {"br": "55", "us": "1", "ca": "1", "pt": "351", "es": "34", "mx": "52", "ar": "54",
        "cl": "56", "co": "57", "py": "595", "uy": "598", "gb": "44", "ie": "353", "au": "61",
        "it": "39", "fr": "33", "de": "49", "jp": "81"}


def _e(t) -> str:
    """Escapa texto vindo do OSM/IA/usuário antes de inserir no HTML gerado
    (evita quebrar o layout ou injetar tags quando o nome/endereço tem
    caracteres como & < > " ')."""
    return html.escape(str(t or ""), quote=True)


def render_site(biz: Dict[str, Any], copy: Dict[str, Any], theme: str = "esmeralda", lang: str = "pt") -> str:
    L = I18N.get(lang, I18N["pt"])
    T = L["ui"]
    lk = lang if lang in I18N else "pt"
    c1, c2, c3, c4 = THEMES.get(theme, THEMES["esmeralda"])
    # valores "crus" (sem escapar) — usados no JSON-LD e em cálculos internos
    name = biz.get("name") or {"pt": "Meu Negócio", "en": "My Business", "es": "Mi Negocio"}[lk]
    cat = biz.get("category") or {"pt": "Negócio Local", "en": "Local Business", "es": "Negocio Local"}[lk]
    city = biz.get("city") or ""
    addr = ", ".join(x for x in [biz.get("address"), city, biz.get("state")] if x)
    phone = biz.get("phone") or biz.get("whatsapp") or ""
    iso = (biz.get("iso") or ("br" if lang == "pt" else "us")).lower()
    dial = DIAL.get(iso, "")
    wa = re.sub(r"\D", "", biz.get("whatsapp") or biz.get("phone") or "")
    if wa and dial and not wa.startswith(dial):
        wa = dial + wa.lstrip("0")
    hours = biz.get("hours") or T["default_hours"]
    lat, lon = biz.get("lat"), biz.get("lon")
    maps = f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=18/{lat}/{lon}" if lat else "#"
    gmaps = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}" if lat else "#"
    svcs = "".join(
        f'<article class="card"><div class="ico">{i+1}</div><h3>{_e(t)}</h3><p>{_e(x)}</p></article>'
        for i, (t, x) in enumerate(copy["services"]))
    about_html = "".join(f"<p>{_e(p.strip())}</p>" for p in str(copy["about"]).split("\n") if p.strip())
    use_wa = iso not in ("us", "ca", "gb", "ie", "au", "jp", "fr", "de")
    lang_tag = {"pt": "pt-BR", "en": "en-US", "es": "es"}.get(lang, "pt-BR")
    if wa and use_wa:
        wa_btn = f'<a class="btn wa" href="https://wa.me/{_e(wa)}" target="_blank" rel="noopener">WhatsApp</a>'
    elif phone:
        wa_btn = f'<a class="btn" href="tel:{_e(phone)}">{_e(T["talk"])}</a>'
    else:
        wa_btn = ""
    tel_btn = (f'<a class="btn ghost" href="tel:{_e(phone)}">{_e(phone)}</a>' if phone else "")

    return f"""<!DOCTYPE html>
<html lang="{lang_tag}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(name)} — {_e(cat)} em {_e(city)}</title>
<meta name="description" content="{_e(copy['seo'])}">
<meta property="og:title" content="{_e(name)} — {_e(cat)}">
<meta property="og:description" content="{_e(copy['seo'])}">
<meta property="og:type" content="website">
<script type="application/ld+json">
{json.dumps({"@context":"https://schema.org","@type":"LocalBusiness","name":name,"description":copy['seo'],
 "address":{"@type":"PostalAddress","streetAddress":biz.get("address",""),"addressLocality":city,
 "addressRegion":biz.get("state",""),"postalCode":biz.get("postcode",""),"addressCountry":"BR"},
 "telephone":phone,"openingHours":hours,
 "geo":{"@type":"GeoCoordinates","latitude":lat,"longitude":lon}}, ensure_ascii=False).replace("</", "<\\/")}
</script>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
:root{{--c1:{c1};--c2:{c2};--c3:{c3};--c4:{c4}}}
body{{font-family:'Segoe UI',system-ui,-apple-system,Arial,sans-serif;color:#1f2937;background:#fff;line-height:1.65}}
a{{text-decoration:none}}
header{{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);backdrop-filter:blur(8px);border-bottom:1px solid #e5e7eb}}
nav{{max-width:1100px;margin:auto;display:flex;align-items:center;justify-content:space-between;padding:14px 20px;gap:16px}}
.logo{{font-weight:800;font-size:19px;color:var(--c1);letter-spacing:-.4px}}
nav ul{{display:flex;gap:22px;list-style:none;font-size:15px}}
nav a{{color:#374151}} nav a:hover{{color:var(--c1)}}
.hero{{background:linear-gradient(135deg,var(--c1),var(--c2));color:#fff;padding:92px 20px 100px;text-align:center}}
.hero .tag{{display:inline-block;background:rgba(255,255,255,.18);padding:6px 16px;border-radius:99px;font-size:13px;letter-spacing:.6px;text-transform:uppercase;margin-bottom:18px}}
.hero h1{{font-size:clamp(32px,6vw,54px);line-height:1.1;letter-spacing:-1.4px;margin-bottom:16px}}
.hero p{{font-size:19px;opacity:.95;max-width:640px;margin:auto}}
.btns{{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-top:32px}}
.btn{{display:inline-block;padding:14px 28px;border-radius:10px;font-weight:700;font-size:16px;background:#fff;color:var(--c1);box-shadow:0 8px 24px rgba(0,0,0,.14);transition:.2s}}
.btn:hover{{transform:translateY(-2px)}}
.btn.wa{{background:#25D366;color:#fff}}
.btn.ghost{{background:transparent;color:#fff;border:2px solid rgba(255,255,255,.7);box-shadow:none}}
section{{max-width:1100px;margin:auto;padding:76px 20px}}
h2{{font-size:32px;letter-spacing:-.8px;margin-bottom:14px;color:var(--c4)}}
.sub{{color:#6b7280;margin-bottom:38px;max-width:620px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:22px}}
.card{{background:var(--c3);border:1px solid rgba(0,0,0,.05);border-radius:16px;padding:28px}}
.ico{{width:42px;height:42px;border-radius:12px;background:var(--c1);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;margin-bottom:14px}}
.card h3{{font-size:18px;margin-bottom:8px;color:var(--c4)}}
.card p{{color:#4b5563;font-size:15px}}
.about{{background:var(--c3)}}
.about .inner{{max-width:1100px;margin:auto;padding:76px 20px;display:grid;grid-template-columns:1fr 1fr;gap:44px;align-items:center}}
.about p{{margin-bottom:14px;color:#374151}}
.facts{{background:#fff;border-radius:16px;padding:28px;box-shadow:0 10px 30px rgba(0,0,0,.06)}}
.fact{{display:flex;gap:14px;padding:13px 0;border-bottom:1px solid #f1f5f9}}
.fact:last-child{{border:0}}
.fact b{{display:block;color:var(--c4);font-size:14px}}
.fact span{{color:#6b7280;font-size:15px}}
.cta{{background:var(--c4);color:#fff;text-align:center}}
.cta h2{{color:#fff}} .cta .sub{{color:rgba(255,255,255,.75);margin:auto auto 30px}}
footer{{background:#0b1220;color:#94a3b8;text-align:center;padding:36px 20px;font-size:14px}}
footer b{{color:#fff}}
@media(max-width:800px){{.about .inner{{grid-template-columns:1fr}}nav ul{{display:none}}}}
@media print{{header,.btns{{display:none}}.hero{{padding:40px 20px}}}}
</style>
</head>
<body>
<header><nav>
  <div class="logo">{_e(name)}</div>
  <ul><li><a href="#sobre">{T["about"]}</a></li><li><a href="#servicos">{T["services"]}</a></li><li><a href="#contato">{T["contact"]}</a></li></ul>
  {f'<a class="btn" style="padding:9px 18px;font-size:14px" href="{("https://wa.me/" + _e(wa)) if (wa and use_wa) else ("tel:" + _e(phone))}" target="_blank">{T["talk"]}</a>' if (wa or phone) else ''}
</nav></header>

<div class="hero">
  <span class="tag">{_e(cat)}{' • ' + _e(city) if city else ''}</span>
  <h1>{_e(name)}</h1>
  <p>{_e(copy['tagline'])}</p>
  <div class="btns">{wa_btn}{tel_btn}<a class="btn ghost" href="#contato">{T["route"]}</a></div>
</div>

<div class="about" id="sobre"><div class="inner">
  <div><h2>{T["about"]}</h2>{about_html}</div>
  <div class="facts">
    <div class="fact"><b>{T["addr"]}</b><span>{_e(addr) or T["no_addr"]}</span></div>
    <div class="fact"><b>{T["hours"]}</b><span>{_e(hours)}</span></div>
    <div class="fact"><b>{T["phone"]}</b><span>{_e(phone) or T["no_phone"]}</span></div>
    <div class="fact"><b>{T["cat"]}</b><span>{_e(cat)}</span></div>
  </div>
</div></div>

<section id="servicos">
  <h2>{T["offer"]}</h2>
  <p class="sub">{T["offer_sub"]}</p>
  <div class="grid">{svcs}</div>
</section>

<section class="cta" id="contato" style="max-width:none">
  <div style="max-width:1100px;margin:auto">
    <h2>{_e(copy['cta'])}</h2>
    <p class="sub">{_e(addr) or _e(city)}{' • ' + _e(hours) if hours else ''}</p>
    <div class="btns">{wa_btn}{tel_btn}
      <a class="btn" href="{gmaps}" target="_blank" rel="noopener">{T["map"]}</a></div>
  </div>
</section>

<footer>
  <p><b>{_e(name)}</b> — {_e(cat)}{(", " + _e(city)) if city else ""}</p>
  <p style="margin-top:6px">{_e(addr)}</p>
  <p style="margin-top:14px;font-size:12px;opacity:.7">{T["made"]} • {T["mapdata"]}: <a href="{maps}" style="color:#94a3b8" target="_blank">OpenStreetMap</a></p>
</footer>
</body></html>"""


@app.post("/api/generate")
async def generate(payload: Dict[str, Any] = Body(...)):
    biz = payload.get("business") or {}
    theme = payload.get("theme") or "esmeralda"
    key = (payload.get("api_key") or "").strip()
    model = (payload.get("model") or "").strip()
    extra = payload.get("notes") or ""
    lang = payload.get("lang") or "pt"
    if lang not in I18N:
        lang = "pt"
    ai = await ai_copy(biz, key, model, extra, lang) if key else None
    copy = build_copy(biz, ai, lang)
    html = render_site(biz, copy, theme, lang)
    slug = slugify(biz.get("name", "negocio"))
    path = os.path.join(OUT, f"{slug}.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return {"slug": slug, "html": html, "ai_used": bool(ai), "file": f"out/{slug}.html", "copy": copy}


# ---------------------------------------------------------------- downloads
@app.post("/api/zip")
async def make_zip(payload: Dict[str, Any] = Body(...)):
    html = payload.get("html", "")
    slug = slugify(payload.get("slug") or "site")
    name = payload.get("name") or slug
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("index.html", html)
        z.writestr("robots.txt", "User-agent: *\nAllow: /\n")
        z.writestr("_redirects", "/*  /index.html  200\n")
        z.writestr("COMO-PUBLICAR.txt", f"""SITE DE {name.upper()} — COMO COLOCAR NO AR DE GRAÇA
=========================================================

OPÇÃO 1 — Netlify Drop (mais rápido, ~30 segundos, sem cadastro obrigatório)
  1. Descompacte este ZIP em uma pasta.
  2. Acesse https://app.netlify.com/drop
  3. Arraste a PASTA inteira para a área indicada.
  4. Pronto: você recebe um endereço tipo https://{slug}.netlify.app
  5. (Opcional) Crie conta grátis para renomear o site e manter para sempre.

OPÇÃO 2 — Cloudflare Pages (grátis, tráfego ilimitado)
  1. Conta grátis em https://pages.cloudflare.com
  2. "Create a project" > "Upload assets" > arraste a pasta.

OPÇÃO 3 — GitHub Pages (grátis para sempre)
  1. Crie um repositório público em https://github.com/new
  2. Envie o arquivo index.html
  3. Settings > Pages > Branch: main / root > Save
  4. Fica em https://SEUUSUARIO.github.io/REPOSITORIO

DOMÍNIO PRÓPRIO
  Todas as três opções aceitam domínio próprio grátis (você só paga o domínio,
  cerca de R$ 40/ano em registro.br).

ARQUIVOS
  index.html ......... o site completo (tudo embutido, sem dependências)
  _redirects ......... configuração de rotas do Netlify
  robots.txt ......... libera indexação no Google
""")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f'attachment; filename="{slug}-site.zip"'})


@app.post("/api/pdf")
async def make_pdf(payload: Dict[str, Any] = Body(...)):
    from fpdf import FPDF
    biz = payload.get("business") or {}
    copy = payload.get("copy") or {}
    slug = slugify(biz.get("name", "negocio"))

    def s(t):
        return str(t or "").encode("latin-1", "replace").decode("latin-1")

    pdf = FPDF()
    pdf.set_auto_page_break(True, 18)
    pdf.add_page()
    pdf.set_fill_color(15, 118, 110)
    pdf.rect(0, 0, 210, 54, "F")
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 24)
    pdf.set_xy(16, 16)
    pdf.multi_cell(178, 10, s(biz.get("name", "Negócio")))
    pdf.set_font("Helvetica", "", 12)
    pdf.set_x(16)
    pdf.cell(178, 8, s(f"{biz.get('category','')} — {biz.get('city','')}"))
    pdf.ln(28)
    pdf.set_text_color(30, 30, 30)

    def h(t):
        pdf.ln(4)
        pdf.set_font("Helvetica", "B", 14)
        pdf.set_text_color(15, 118, 110)
        pdf.cell(0, 9, s(t), new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(30, 30, 30)
        pdf.set_font("Helvetica", "", 11)

    h("Proposta de site")
    pdf.set_x(10)
    pdf.multi_cell(0, 6, s(f"Este documento apresenta o conteúdo do site criado para {biz.get('name')}. "
                           f"O site é 100% responsivo, otimizado para Google (SEO + dados estruturados) "
                           f"e pode ser publicado gratuitamente em Netlify, Cloudflare Pages ou GitHub Pages."))
    h("Dados do negócio")
    for k, v in [("Endereço", biz.get("address")), ("Cidade", biz.get("city")),
                 ("Telefone", biz.get("phone")), ("WhatsApp", biz.get("whatsapp")),
                 ("E-mail", biz.get("email")), ("Horário", biz.get("hours")),
                 ("Coordenadas", f"{biz.get('lat')}, {biz.get('lon')}"),
                 ("Possui site?", "Não" if not biz.get("has_site") else biz.get("website"))]:
        if v:
            pdf.set_x(10)
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(38, 6, s(k + ":"))
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 6, s(v), new_x="LMARGIN", new_y="NEXT")
    h("Frase de destaque")
    pdf.set_x(10)
    pdf.multi_cell(0, 6, s(copy.get("tagline", "")), new_x="LMARGIN", new_y="NEXT")
    h("Sobre")
    pdf.set_x(10)
    pdf.multi_cell(0, 6, s(copy.get("about", "")), new_x="LMARGIN", new_y="NEXT")
    h("Serviços em destaque")
    for t, x in copy.get("services", []):
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_x(10)
        pdf.multi_cell(0, 6, s("• " + t), new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        pdf.set_x(10)
        pdf.multi_cell(0, 6, s("   " + x), new_x="LMARGIN", new_y="NEXT")
    h("Como publicar gratuitamente")
    pdf.set_x(10)
    pdf.multi_cell(0, 6, s("1) Netlify Drop: app.netlify.com/drop — arraste a pasta do ZIP.\n"
                           "2) Cloudflare Pages: pages.cloudflare.com — upload direto.\n"
                           "3) GitHub Pages: repositório público + Settings > Pages.\n"
                           "Todas gratuitas, com HTTPS e domínio próprio opcional."))
    pdf.ln(6)
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(120, 120, 120)
    pdf.set_x(10)
    pdf.multi_cell(0, 5, s("Gerado por SiteForge IA • Dados públicos do OpenStreetMap (ODbL)."))

    data = bytes(pdf.output())
    return StreamingResponse(io.BytesIO(data), media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="{slug}-proposta.pdf"'})


@app.post("/api/csv")
async def make_csv(payload: Dict[str, Any] = Body(...)):
    import csv
    rows = payload.get("results") or []
    buf = io.StringIO()
    cols = ["name", "category", "address", "city", "phone", "whatsapp", "email", "hours", "has_site", "website", "lat", "lon", "score"]
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore", delimiter=";")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return StreamingResponse(io.BytesIO(buf.getvalue().encode("utf-8-sig")), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="leads-sem-site.csv"'})


# ---------------------------------------------------------------- chat
KB = [
    (r"netlify|publicar|hospedar|hospedagem|no ar|deploy",
     "Para publicar de graça: baixe o ZIP, descompacte e arraste a pasta em app.netlify.com/drop. "
     "Em ~30 segundos você recebe um endereço https com SSL. Alternativas igualmente gratuitas: "
     "Cloudflare Pages (tráfego ilimitado) e GitHub Pages. Todas aceitam domínio próprio depois."),
    (r"pdf",
     "O botão 'Baixar PDF' gera uma proposta comercial com os dados do negócio, o texto do site e o passo a passo "
     "de publicação. É ótimo para imprimir e levar na visita ao lojista."),
    (r"sem site|não tem site|nao tem site|encontrar|buscar|lead",
     "A busca usa o OpenStreetMap e filtra estabelecimentos que NÃO possuem a tag de website. "
     "Dica: busque por 'Cidade, Estado, Brasil' e use o raio em metros para focar num bairro. "
     "O score mostra quais leads têm telefone/endereço/horário — esses são os mais fáceis de fechar."),
    (r"preço|preco|cobrar|vender|quanto",
     "Referência de mercado no Brasil para site one-page de pequeno negócio: R$ 500 a R$ 1.500 na criação "
     "e R$ 50 a R$ 150/mês de manutenção. Como a hospedagem é gratuita, a manutenção é margem quase pura. "
     "Estratégia que funciona: gere o site ANTES, mostre pronto no celular e cobre para publicar."),
    (r"chave|api|openrouter|groq|ia|modelo",
     "A IA de texto é opcional. Sem chave, o app usa templates prontos em português. Com uma chave gratuita do "
     "OpenRouter (modelos com ':free') ou do Groq, os textos ficam personalizados. Cole a chave no campo do topo — "
     "ela fica só no seu navegador."),
    (r"limite|grátis|gratis|pagar|custo",
     "Nada aqui é pago: OpenStreetMap é aberto, o gerador roda local, o chat não tem limite de mensagens e as "
     "hospedagens sugeridas têm plano gratuito permanente."),
    (r"tema|cor|design|layout",
     "Troque o tema no seletor (esmeralda, índigo, laranja, vinho, grafite) e clique em gerar de novo. "
     "O HTML sai com CSS embutido, então você pode editar as cores direto no arquivo."),
    (r"whatsapp|contato|telefone",
     "Quando o negócio tem telefone no OSM, o site já sai com botão de WhatsApp (wa.me) e link de ligação. "
     "Se não tiver, edite o campo antes de gerar — os campos do painel são editáveis."),
]


@app.post("/api/chat")
async def chat(payload: Dict[str, Any] = Body(...)):
    msg = (payload.get("message") or "").strip()
    key = (payload.get("api_key") or "").strip()
    model = (payload.get("model") or "").strip()
    history = payload.get("history") or []
    ctx = payload.get("context") or ""

    if key:
        base = "https://openrouter.ai/api/v1/chat/completions"
        mdl = model or "meta-llama/llama-3.3-70b-instruct:free"
        if key.startswith("gsk_"):
            base = "https://api.groq.com/openai/v1/chat/completions"
            mdl = model or "llama-3.3-70b-versatile"
        sysmsg = ("Você é o assistente do SiteForge IA, um app que encontra lojas sem site pelo OpenStreetMap, "
                  "gera sites prontos e ensina a publicar de graça (Netlify Drop, Cloudflare Pages, GitHub Pages). "
                  "Responda em português do Brasil, direto e prático. Contexto atual: " + str(ctx)[:1500])
        msgs = [{"role": "system", "content": sysmsg}] + history[-10:] + [{"role": "user", "content": msg}]
        try:
            async with httpx.AsyncClient(timeout=90) as c:
                r = await c.post(base, headers={"Authorization": f"Bearer {key}"},
                                 json={"model": mdl, "messages": msgs, "temperature": 0.7})
                return {"reply": r.json()["choices"][0]["message"]["content"], "engine": "ia"}
        except Exception as e:
            pass  # cai no modo local

    low = msg.lower()
    for pat, ans in KB:
        if re.search(pat, low):
            return {"reply": ans, "engine": "local"}
    return {"reply": ("Posso ajudar com: encontrar lojas sem site numa região, gerar o site, baixar PDF/ZIP, "
                      "publicar de graça, precificar o serviço e configurar a IA de texto. "
                      "Sobre o que você quer falar? (dica: pergunte 'como publicar' ou 'quanto cobrar')"),
            "engine": "local"}


app.mount("/", StaticFiles(directory=os.path.join(BASE, "static"), html=True), name="static")
