#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 -c "import fastapi,uvicorn,fpdf" 2>/dev/null || pip install -q -r requirements.txt
exec python3 -m uvicorn app:app --host 0.0.0.0 --port 7860
