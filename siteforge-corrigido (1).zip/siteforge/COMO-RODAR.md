# SiteForge IA — como rodar na sua máquina

```bash
pip install -r requirements.txt
python -m uvicorn app:app --host 0.0.0.0 --port 7860
```
Abra http://localhost:7860

## Chave de IA gratuita (opcional)
- OpenRouter: https://openrouter.ai/keys → use modelos com `:free`
- Groq: https://console.groq.com/keys (chave começa com `gsk_`)
Cole no campo do topo. Sem chave o app funciona igual, com textos de template.
